# CARES — Crowding Aware Rényi Entropy Seeding for k-means

Code accompanying the paper *"CARES: A Deterministic Crowding Aware Rényi Entropy Seeding Method for K-Means
Cluster Initialization"*. CARES is a deterministic k-means seeding rule that scores every point with a hybrid
crowding distance, a locally adaptive relative density and a Parzen-based local quadratic Rényi information
potential, and selects the seeds greedily by trading this potential against separation from the seeds already chosen.

## Contents

| File | Purpose |
|---|---|
| `cares_core.py` | The proposed method (`cares_init`), the eleven baseline initialisers (Forgy, Random Partition, k-means++, Maximin, KKZ, Var-Part, PCA-Part, ROBIN, density-peak seeding, CKmeans, FCKmeans), the Lloyd runner, metrics and the statistical tests |
| `benchmark_data.py` | Automatic download and preprocessing of the 29 public benchmark datasets |
| `run_benchmark.py` | Full-data protocol (30 seeds for stochastic methods) and 90 % sub-sampling protocol, Friedman / Nemenyi / Wilcoxon–Holm tests |
| `run_extras.py` | Ablation study, noise robustness, parameter sensitivity and scalability / seeding time |
| `cwru_data.py`, `run_application.py` | Condition-monitoring application: clustering of bearing vibration windows (CWRU data) with the same 12 initialisers and protocols |
| `results_*` | Output tables and raw per-run results of every experiment reported in the paper |

## Quick start

```bash
pip install -r requirements.txt
python run_benchmark.py results_benchmark       # about 5 minutes on one CPU core
python run_extras.py results_extras
python run_application.py results_application   # clones the CWRU mirror automatically
```

Using the method on your own data:

```python
import numpy as np
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from cares_core import cares_init

X = StandardScaler().fit_transform(X_raw)
seeds = cares_init(X, k=10)                       # deterministic: the same seeds on every call
km = KMeans(n_clusters=10, init=seeds, n_init=1).fit(X)
```

## Notes on the baselines

* CKmeans and FCKmeans follow the MATLAB code published by their author
  (<https://github.com/Layebuniv/fckmeans>, `ckmeans.m` and `fckmeansBest.m`).
* ROBIN is run with 10 neighbours and a tolerance of 0.05. Every initialiser feeds the same Lloyd routine
  (one initialisation, at most 300 iterations, tolerance 1e-4).
* Datasets: `deric/clustering-benchmark` (GitHub) and scikit-learn's Digits; bearing data: Case Western Reserve
  University Bearing Data Center (<https://engineering.case.edu/bearingdatacenter>).

## Reproducibility

CARES contains no random component. The stochastic baselines and the random sub-samples use fixed seeds
(see the scripts). Results were produced with scikit-learn 1.9.1 on a single CPU core.
