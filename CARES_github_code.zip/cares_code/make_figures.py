"""
make_figures.py -- bold figures of the paper from the result tables written by run_benchmark.py, run_extras.py and
run_application.py.  Usage: python make_figures.py [figure_dir]
"""
import os, sys, json
import numpy as np, pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from cares_core import METHOD_NAMES

FIG = sys.argv[1] if len(sys.argv) > 1 else "figures"
os.makedirs(FIG, exist_ok=True)
plt.rcParams.update({"font.family": "DejaVu Sans", "font.weight": "bold", "font.size": 11, "axes.labelweight": "bold",
                     "axes.titleweight": "bold", "axes.titlesize": 13, "axes.labelsize": 12, "axes.linewidth": 1.6,
                     "pdf.fonttype": 42, "ps.fonttype": 42, "lines.linewidth": 2.2})
PALETTE = {"Forgy": "#9e9e9e", "RandPart": "#795548", "KMeans++": "#1f77b4", "Maximin": "#17becf", "KKZ": "#bcbd22",
           "Var-Part": "#9467bd", "PCA-Part": "#e377c2", "ROBIN": "#ff7f0e", "DPC-Seed": "#2ca02c",
           "CKmeans": "#8c564b", "FCKmeans": "#7f7f7f", "CARES": "#d62728"}
DISPLAY = {"RandPart": "Rand. Part.", "DPC-Seed": "DPC"}
def nm(m): return DISPLAY.get(m, m)

def bold_axes(ax, fs=10):
    labs = list(ax.get_xticklabels()) + list(ax.get_yticklabels())
    if hasattr(ax, "get_zticklabels"): labs += list(ax.get_zticklabels())
    for t in labs: t.set_fontweight("bold"); t.set_fontsize(fs)

def save(fig, name):
    for xy in [(0.0, 0.0), (1.0, 1.0), (0.0, 1.0), (1.0, 0.0)]:
        fig.text(xy[0], xy[1], " ", alpha=0.0, fontsize=1)
    fig.savefig(os.path.join(FIG, name + ".pdf"), bbox_inches="tight", pad_inches=0.25)
    fig.savefig(os.path.join(FIG, name + ".png"), dpi=200, bbox_inches="tight", pad_inches=0.25)
    plt.close(fig)

def cd_diagram(ax, avg_ranks, cd, title):
    ar = avg_ranks.sort_values(); names = list(ar.index); vals = ar.values; k = len(vals); lo, hi = 1, k
    ax.set_xlim(lo - 2.9, hi + 2.9); ax.axis("off"); ax.hlines(0, lo, hi, color="black", lw=2)
    for r in range(lo, hi + 1):
        ax.vlines(r, 0, 0.18, color="black", lw=2); ax.text(r, 0.32, str(r), ha="center", fontsize=11, fontweight="bold")
    ax.hlines(1.2, lo, lo + cd, color="black", lw=2.5); ax.vlines([lo, lo + cd], 1.1, 1.3, color="black", lw=2.5)
    ax.text(lo + cd / 2, 1.38, f"CD = {cd:.2f}", ha="center", fontsize=11, fontweight="bold")
    cliques = []
    for i in range(k):
        j = i
        while j + 1 < k and vals[j + 1] - vals[i] <= cd: j += 1
        if j > i and not any(a <= i and j <= b for a, b in cliques): cliques.append((i, j))
    for c, (i, j) in enumerate(cliques):
        ax.hlines(-0.28 - 0.2 * c, vals[i] - 0.04, vals[j] + 0.04, color="black", lw=4.5)
    off = 0.35 + 0.2 * len(cliques); half = (k + 1) // 2
    ax.set_ylim(-(off + half * 0.62 + 0.5), 1.8)
    for i, (n_, v) in enumerate(zip(names, vals)):
        col = PALETTE.get(n_, "black")
        if i < half:
            yy = -off - i * 0.62; ax.vlines(v, yy, 0, color=col, lw=1.8); ax.hlines(yy, lo - 0.25, v, color=col, lw=1.8)
            ax.text(lo - 0.3, yy, f"{nm(n_)} ({v:.2f})", ha="right", va="center", fontsize=10.5, fontweight="bold", color=col)
        else:
            yy = -off - (k - 1 - i) * 0.62; ax.vlines(v, yy, 0, color=col, lw=1.8); ax.hlines(yy, v, hi + 0.25, color=col, lw=1.8)
            ax.text(hi + 0.3, yy, f"({v:.2f}) {nm(n_)}", ha="left", va="center", fontsize=10.5, fontweight="bold", color=col)
    ax.set_title(title, fontweight="bold", fontsize=13, pad=2)

def cd_figure(ranks_csv, fried_csv, prefix, out):
    R = pd.read_csv(ranks_csv); F = pd.read_csv(fried_csv)
    fig, axes = plt.subplots(2, 1, figsize=(11, 12))
    for ri, (lab, tag) in enumerate([("SSE gap (%)", "(a) Final SSE gap"), ("ARI", "(b) ARI")]):
        ar = R[(R.protocol == "Full-data") & (R.metric == lab)].set_index("method")["avg_rank"]
        f = F[(F.protocol == "Full-data") & (F.metric == lab)].iloc[0]
        cd_diagram(axes[ri], ar, f["nemenyi_CD"], f"{tag}, Friedman p = {f['friedman_p']:.1e}")
    fig.subplots_adjust(hspace=0.12, left=0.01, right=0.99)
    save(fig, out)

def set_zoom(ax, box, zoom=0.86):
    try: ax.set_box_aspect(box, zoom=zoom)
    except TypeError: ax.set_box_aspect(box)

def bars3d(ax, M, xlabels, ylabels, zlabel, colors, zlim=None, xfs=9, yfs=10, elev=30, azim=-52, box=(2.0, 1.1, 0.9)):
    nx, ny = M.shape
    xs, ys = np.meshgrid(np.arange(nx), np.arange(ny), indexing="ij"); xs, ys, zs = xs.ravel(), ys.ravel(), np.nan_to_num(M.ravel())
    cols = [colors[xlabels[i]] for i in range(nx) for _ in range(ny)]
    ax.bar3d(xs - .25, ys - .25, np.zeros_like(zs), .5, .5, zs, color=cols, edgecolor="black", linewidth=0.35, shade=True)
    ax.set_xticks(np.arange(nx)); ax.set_yticks(np.arange(ny))
    ax.set_xticklabels([nm(x) for x in xlabels], rotation=38, ha="right", va="center", fontsize=xfs)
    ax.set_yticklabels(ylabels, ha="left", va="center", fontsize=yfs)
    ax.set_zlabel(zlabel, labelpad=12, fontweight="bold")
    hi = float(np.nanmax(M)); ax.set_zlim(0, hi * 1.08 if zlim is None else zlim)
    ax.view_init(elev=elev, azim=azim); ax.set_xlim(-0.7, nx - 0.3); ax.set_ylim(-0.7, ny - 0.3); set_zoom(ax, box, 0.95)
    bold_axes(ax, 9)

R = "results_benchmark"; X = "results_extras"; A = "results_application"
# ---- Fig. 2: critical-difference diagrams, benchmark (full-data protocol)
cd_figure(f"{R}/average_ranks.csv", f"{R}/friedman_nemenyi.csv", "bench", "fig_cd")

# ---- Fig. 3 panels: noise robustness, sensitivity, seeding time
noise = pd.read_csv(f"{X}/table_noise.csv")
Mx = noise.pivot(index="method", columns="noise", values="ari_inliers").reindex(METHOD_NAMES)
fig = plt.figure(figsize=(6.2, 5.6)); ax = fig.add_subplot(111, projection="3d")
bars3d(ax, Mx.values, METHOD_NAMES, [f"{int(100 * v)}%" for v in Mx.columns], "ARI (inliers)", PALETTE, zlim=1.05)
ax.set_xlabel("Method", labelpad=38); ax.set_ylabel("Noise", labelpad=14); ax.set_title("(a) Noise robustness", pad=2)
save(fig, "r_a")

sens = pd.read_csv(f"{X}/table_sensitivity_grid.csv"); Mg = sorted(sens.m.unique()); Bg = sorted(sens.beta.unique())
Z = sens.pivot(index="m", columns="beta", values="sse_gap_pct").loc[Mg, Bg].values
mg, bg = np.meshgrid(Mg, Bg, indexing="ij")
fig = plt.figure(figsize=(6.0, 5.2)); ax = fig.add_subplot(111, projection="3d")
ax.plot_surface(mg, np.log2(bg), Z, cmap="plasma_r", edgecolor="black", linewidth=0.5, alpha=0.92)
j = np.unravel_index(np.nanargmin(Z), Z.shape)
ax.scatter(mg[j], np.log2(bg[j]), Z[j], s=260, c="red", marker="*", edgecolor="black", depthshade=False, zorder=20)
ax.set_xlabel("m", labelpad=8); ax.set_ylabel("β", labelpad=8); ax.set_zlabel("SSE gap (%)", labelpad=10)
ax.set_yticks(np.log2(Bg)); ax.set_yticklabels([str(b) for b in Bg]); ax.set_title("(b) Sensitivity to m and β", pad=2)
ax.view_init(elev=28, azim=-130); set_zoom(ax, (1.2, 1.2, 0.85), 0.9); bold_axes(ax, 10)
save(fig, "r_b")

sc = pd.read_csv(f"{X}/table_scalability.csv"); NS = sorted(sc.n.unique())
fig = plt.figure(figsize=(6.4, 5.6)); ax = fig.add_subplot(111, projection="3d")
for mi, mth in enumerate(METHOD_NAMES):
    d_ = sc[sc.method == mth].sort_values("n")
    if len(d_) == 0: continue
    xs = np.log10(d_["n"].values); zs = np.log10(d_["t_init"].values + 1e-5)
    ax.plot(xs, np.full_like(xs, mi), zs, color=PALETTE[mth], lw=2.6, marker="o", markersize=6, markeredgecolor="black")
ax.set_yticks(range(len(METHOD_NAMES))); ax.set_yticklabels([nm(m) for m in METHOD_NAMES], fontsize=8, ha="left")
ax.set_xticks(np.log10(NS)); ax.set_xticklabels([f"{n // 1000}k" for n in NS])
ax.set_xlabel("n", labelpad=10); ax.set_ylabel("Method", labelpad=26); ax.set_zlabel("log10 time (s)", labelpad=10)
ax.set_title("(c) Seeding time", pad=2); ax.view_init(elev=22, azim=-58); set_zoom(ax, (1.4, 1.5, 0.9), 0.9); bold_axes(ax, 9)
save(fig, "r_c")

# ---- application figures
cd_figure(f"{A}/app_average_ranks.csv", f"{A}/app_friedman_nemenyi.csv", "app", "app_cd")
for tag, name in (("full", "app_a"), ("sub", "app_b")):
    M = np.column_stack([pd.read_csv(f"{A}/app_table_{t}_{tag}.csv", index_col=0).reindex(METHOD_NAMES)["ari"].values for t in ("T10", "T4")])
    fig = plt.figure(figsize=(6.2, 5.4)); ax = fig.add_subplot(111, projection="3d")
    bars3d(ax, M, METHOD_NAMES, ["10 classes", "4 classes"], "Mean ARI", PALETTE, zlim=max(0.8, float(np.nanmax(M)) * 1.08))
    ax.set_xlabel("Method", labelpad=38); ax.set_ylabel("Task", labelpad=14)
    ax.set_title("(a) Full data" if tag == "full" else "(b) 90% subsampling", pad=2)
    save(fig, name)
print("figures written to", FIG)
