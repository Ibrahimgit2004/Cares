"""
run_extras.py -- ablation study, noise robustness, parameter sensitivity and scalability of CARES
(Experiments 3-6 of the study).  Usage:  python run_extras.py [out_dir]
"""
import os, sys, time
import numpy as np, pandas as pd
from threadpoolctl import threadpool_limits
from sklearn.datasets import make_blobs
from sklearn.preprocessing import StandardScaler
from cares_core import *
from benchmark_data import load_benchmark

OUT = sys.argv[1] if len(sys.argv) > 1 else "extras_outputs"
os.makedirs(OUT, exist_ok=True)
R_ABLATION, R_NOISE, R_SENS, SUB_FRAC = 20, 10, 5, 0.90
NOISE_LEVELS = [0.0, 0.05, 0.10, 0.20]
SCALE_NS = [2000, 5000, 10000, 20000, 50000, 100000]
T0 = time.time()
def log(m): print(f"[{(time.time()-T0)/60:6.1f} min] {m}", flush=True)
DATA, META = load_benchmark(os.path.join(OUT, "data_cache"))

# ---------------- Experiment 3: ablation (90 % sub-samples)
ABLATIONS = {
    "CARES (full)":          dict(),
    "w/o feature entropy":   dict(use_feature_entropy=False),
    "axis-CD only":          dict(cd_mode="axis"),
    "kNN-CD only":           dict(cd_mode="knn"),
    "w/o local adaptivity":  dict(use_local_adaptive=False),
    "w/o Renyi entropy":     dict(use_entropy=False),
    "w/o greedy selection":  dict(greedy=False),
    "w/o mode refinement":   dict(refine=False),
}
def _abl(kw): return lambda X, k, rng: cares_init(X, k, rng, **kw)
rows = []
with threadpool_limits(limits=1):
    for dn, (X, y, grp) in DATA.items():
        k = len(np.unique(y))
        for r in range(R_ABLATION):
            sub = np.random.default_rng(20_000 + r).choice(len(X), int(SUB_FRAC * len(X)), replace=False)
            Xs, ys = X[sub], y[sub]; G = gt_centres_of(Xs, ys) if grp == "Synthetic" else None
            for an, kw in ABLATIONS.items():
                rec = evaluate_once(Xs, ys, k, _abl(kw), seed=r, gt_centres=G)
                rec.update(dataset=dn, group=grp, variant=an, rep=r); rows.append(rec)
        log(f"ablation done: {dn}")
E3 = pd.DataFrame(rows)
b3 = E3.groupby(["dataset", "rep"])["final_sse"].transform("min")
E3["sse_gap_pct"] = 100.0 * (E3["final_sse"] - b3) / b3
E3.to_csv(os.path.join(OUT, "exp3_ablation_runs.csv"), index=False)
ds = E3.groupby(["variant", "dataset"])[["ari", "nmi", "sse_gap_pct", "iters"]].mean().reset_index()
ABL = ds.groupby("variant")[["ari", "nmi", "sse_gap_pct", "iters"]].mean().reindex(list(ABLATIONS)).round(4)
ABL.to_csv(os.path.join(OUT, "table_ablation.csv")); print(ABL.to_string(), flush=True)

# ---------------- Experiment 4: uniform background noise
NOISE_DS = [d for d in ["S1", "R15", "D31", "Twenty", "Diamond9", "Xclara"] if d in DATA]
rows = []
with threadpool_limits(limits=1):
    for dn in NOISE_DS:
        X, y, grp = DATA[dn]; k = len(np.unique(y)); G = gt_centres_of(X, y)
        lo, hi = X.min(0), X.max(0); pad = 0.1 * (hi - lo)
        for lvl in NOISE_LEVELS:
            for r in range(R_NOISE if lvl > 0 else 1):
                rng = np.random.default_rng(30_000 + r); nz = int(round(lvl * len(X)))
                Xn = np.vstack([X, rng.uniform(lo - pad, hi + pad, size=(nz, X.shape[1]))])
                inl = np.arange(len(X))
                for mth, (f, stoch) in METHODS.items():
                    t0 = time.perf_counter(); C0 = f(Xn, k, np.random.default_rng(r)); ti = time.perf_counter() - t0
                    km = run_lloyd(Xn, C0)
                    rows.append(dict(dataset=dn, noise=lvl, rep=r, method=mth,
                                     ari_inliers=adjusted_rand_score(y, km.labels_[inl]),
                                     nmi_inliers=normalized_mutual_info_score(y, km.labels_[inl]),
                                     ci=centroid_index(km.cluster_centers_, G), iters=int(km.n_iter_), t_init=ti))
        log(f"noise done: {dn}")
E4 = pd.DataFrame(rows); E4["success"] = (E4["ci"] == 0).astype(float)
E4.to_csv(os.path.join(OUT, "exp4_noise_runs.csv"), index=False)
NOISE_T = E4.groupby(["noise", "method"])[["ari_inliers", "nmi_inliers", "ci", "success"]].mean().round(4).reset_index()
NOISE_T.to_csv(os.path.join(OUT, "table_noise.csv"), index=False)
print(NOISE_T.pivot(index="method", columns="noise", values="ari_inliers").round(4).to_string(), flush=True)

# ---------------- Experiment 5: sensitivity to m and beta
M_GRID = [5, 10, 15, 20, 30, 40]; B_GRID = [0.25, 0.5, 1.0, 1.5, 2.0, 3.0]
SENS_DS = [d for d in DATA if DATA[d][0].shape[0] <= 5000]
rows = []
with threadpool_limits(limits=1):
    for dn in SENS_DS:
        X, y, grp = DATA[dn]; k = len(np.unique(y))
        for r in range(R_SENS):
            sub = np.random.default_rng(40_000 + r).choice(len(X), int(SUB_FRAC * len(X)), replace=False)
            Xs, ys = X[sub], y[sub]; res = []
            for mm in M_GRID:
                for bb in B_GRID:
                    km = run_lloyd(Xs, cares_init(Xs, k, m=mm, beta=bb))
                    res.append(dict(dataset=dn, rep=r, m=mm, beta=bb, final_sse=float(km.inertia_),
                                    ari=adjusted_rand_score(ys, km.labels_)))
            bst = min(z["final_sse"] for z in res)
            for z in res: z["sse_gap_pct"] = 100 * (z["final_sse"] - bst) / bst
            rows += res
        log(f"sensitivity done: {dn}")
E5 = pd.DataFrame(rows); E5.to_csv(os.path.join(OUT, "exp5_sensitivity_runs.csv"), index=False)
SENS = E5.groupby(["m", "beta"])[["ari", "sse_gap_pct"]].mean().reset_index()
SENS.to_csv(os.path.join(OUT, "table_sensitivity_grid.csv"), index=False)
print(SENS.pivot(index="m", columns="beta", values="sse_gap_pct").round(3).to_string(), flush=True)

# ---------------- Experiment 6: scalability (Gaussian blobs, d = 8, k = 25)
rows = []
with threadpool_limits(limits=1):
    for n in SCALE_NS:
        Xb, yb = make_blobs(n_samples=n, n_features=8, centers=25, cluster_std=1.0, random_state=7)
        Xb = StandardScaler().fit_transform(Xb)
        for mth, (f, stoch) in METHODS.items():
            if mth == "DPC-Seed" and n > 50000: continue
            ts = []
            for r in range(3 if n <= 20000 else 1):
                t0 = time.perf_counter(); C0 = f(Xb, 25, np.random.default_rng(r)); ts.append(time.perf_counter() - t0)
            t1 = time.perf_counter(); km = run_lloyd(Xb, C0); tk = time.perf_counter() - t1
            rows.append(dict(n=n, method=mth, t_init=float(np.median(ts)), t_kmeans=tk,
                             t_total=float(np.median(ts)) + tk, iters=int(km.n_iter_), ari=adjusted_rand_score(yb, km.labels_)))
        log(f"scalability done: n={n}")
E6 = pd.DataFrame(rows); E6.to_csv(os.path.join(OUT, "table_scalability.csv"), index=False)
print(E6.pivot(index="method", columns="n", values="t_init").round(3).to_string(), flush=True)
log("done")
