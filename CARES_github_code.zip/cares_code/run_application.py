"""
run_application.py -- condition-monitoring application of CARES: clustering of bearing vibration windows
(CWRU data) with the same 12 initialisers and the same two protocols as the benchmark study.
Usage:  python run_application.py [out_dir] [cwru_dir]
"""
import os, sys, time
import numpy as np, pandas as pd
from threadpoolctl import threadpool_limits
from cares_core import *
import cwru_data

OUT = sys.argv[1] if len(sys.argv) > 1 else "application_outputs"
ROOT = cwru_data.ensure_data(sys.argv[2] if len(sys.argv) > 2 else "CWRU-dataset")
os.makedirs(OUT, exist_ok=True)
R_STOCH, R_SUB, SUB_FRAC = 30, 20, 0.90
T0 = time.time()
def log(m): print(f"[{(time.time()-T0)/60:6.1f} min] {m}", flush=True)

SC = cwru_data.all_scenarios(ROOT)
meta = pd.DataFrame([dict(scenario=n, n=X.shape[0], d=X.shape[1], k=len(np.unique(y))) for n, (X, y) in SC.items()])
meta.to_csv(os.path.join(OUT, "scenario_summary.csv"), index=False)
log(f"built {len(SC)} scenarios")

rows = []                                    # ---- full-data protocol
with threadpool_limits(limits=1):
    for sn, (X, y) in SC.items():
        k = len(np.unique(y))
        for mth, (f, stoch) in METHODS.items():
            for r in (range(R_STOCH) if stoch else [0]):
                rec = evaluate_once(X, y, k, mth, seed=r)
                rec.update(dataset=sn, method=mth, run=r); rows.append(rec)
        log(f"full-data done: {sn}")
E1 = pd.DataFrame(rows)
best = E1.groupby("dataset")["final_sse"].min()
E1["sse_gap_pct"] = 100.0 * (E1["final_sse"] - E1["dataset"].map(best)) / E1["dataset"].map(best)
E1.to_csv(os.path.join(OUT, "app_full_runs.csv"), index=False)

rows = []                                    # ---- 90 % sub-sampling protocol
with threadpool_limits(limits=1):
    for sn, (X, y) in SC.items():
        k = len(np.unique(y))
        for r in range(R_SUB):
            sub = np.random.default_rng(10_000 + r).choice(len(X), int(SUB_FRAC * len(X)), replace=False)
            for mth in METHOD_NAMES:
                rec = evaluate_once(X[sub], y[sub], k, mth, seed=r)
                rec.update(dataset=sn, method=mth, rep=r); rows.append(rec)
        log(f"subsampling done: {sn}")
E2 = pd.DataFrame(rows)
b2 = E2.groupby(["dataset", "rep"])["final_sse"].transform("min")
E2["sse_gap_pct"] = 100.0 * (E2["final_sse"] - b2) / b2
E2.to_csv(os.path.join(OUT, "app_subsampling_runs.csv"), index=False)

def mean_table(E):
    g = E.groupby(["dataset", "method"])[["ari", "nmi", "sse_gap_pct", "iters", "t_init"]].mean()
    return g.groupby("method").mean().loc[METHOD_NAMES]
T1, T2 = mean_table(E1), mean_table(E2)
T1.to_csv(os.path.join(OUT, "app_table_mean_full.csv")); T2.to_csv(os.path.join(OUT, "app_table_mean_subsampling.csv"))
for task in ("T10", "T4"):
    for tag, E in (("full", E1), ("sub", E2)):
        sel = E[E.dataset.str.endswith(task)]
        g = sel.groupby(["dataset", "method"])[["ari", "nmi", "sse_gap_pct", "iters"]].mean().groupby("method").mean().loc[METHOD_NAMES]
        g.to_csv(os.path.join(OUT, f"app_table_{task}_{tag}.csv"))
names = list(SC)
R1, F1, W1 = stat_block(E1, "Full-data", names); R2, F2, W2 = stat_block(E2, "90%-subsampling", names)
pd.concat([R1, R2]).to_csv(os.path.join(OUT, "app_average_ranks.csv"), index=False)
pd.concat([F1, F2]).to_csv(os.path.join(OUT, "app_friedman_nemenyi.csv"), index=False)
pd.concat([W1, W2]).to_csv(os.path.join(OUT, "app_wilcoxon_holm.csv"), index=False)
log("FULL-DATA MEANS\n" + T1.round(4).to_string()); log("SUBSAMPLING MEANS\n" + T2.round(4).to_string()); log("done")
