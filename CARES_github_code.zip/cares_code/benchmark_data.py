"""
benchmark_data.py -- automatic download and preprocessing of the 29 benchmark datasets used in the CARES study.
Sources: deric/clustering-benchmark (GitHub) and scikit-learn's bundled Digits.
Preprocessing: identifier/string attributes removed, missing values -> feature medians, constant features dropped,
z-score standardisation; k = number of classes.
"""
import os, csv, time, urllib.request
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.datasets import load_digits

CACHE = os.path.abspath("data_cache")
QUICK_TEST = False
BASES = ["https://raw.githubusercontent.com/deric/clustering-benchmark/master/src/main/resources/datasets/",
         "https://cdn.jsdelivr.net/gh/deric/clustering-benchmark@master/src/main/resources/datasets/"]
# (display name, relative path, group, attributes to drop)
REGISTRY = [
    ("S1", "artificial/s-set1", "Synthetic", ()), ("S2", "artificial/s-set2", "Synthetic", ()),
    ("R15", "artificial/R15", "Synthetic", ()), ("D31", "artificial/D31", "Synthetic", ()),
    ("2d-20c", "artificial/2d-20c-no0", "Synthetic", ()), ("Xclara", "artificial/xclara", "Synthetic", ()),
    ("Hepta", "artificial/hepta", "Synthetic", ()), ("Tetra", "artificial/tetra", "Synthetic", ()),
    ("Ellip-10", "artificial/elliptical_10_2", "Synthetic", ()), ("Twenty", "artificial/twenty", "Synthetic", ()),
    ("Fourty", "artificial/fourty", "Synthetic", ()), ("Diamond9", "artificial/diamond9", "Synthetic", ()),
    ("Sizes3", "artificial/sizes3", "Synthetic", ()), ("Spher-6", "artificial/spherical_6_2", "Synthetic", ()),
    ("Iris", "real-world/iris", "Real", ()), ("Wine", "real-world/wine", "Real", ()),
    ("Glass", "real-world/glass", "Real", ()), ("Ecoli", "real-world/ecoli", "Real", ()),
    ("Yeast", "real-world/yeast", "Real", ()), ("WDBC", "real-world/wdbc", "Real", ("IDNumber",)),
    ("WBC", "real-world/wisc", "Real", ()), ("Segment", "real-world/segment", "Real", ()),
    ("Vowel", "real-world/vowel", "Real", ()), ("Vehicle", "real-world/vehicle", "Real", ()),
    ("Thyroid", "real-world/thy", "Real", ()), ("Zoo", "real-world/zoo", "Real", ()),
    ("Dermatology", "real-world/dermatology", "Real", ()), ("Letter", "real-world/letter", "Real", ()),
]

def fetch_text(rel):
    local = os.path.join(CACHE, rel.replace("/", "__") + ".arff")
    if os.path.exists(local) and os.path.getsize(local) > 100:
        return open(local, encoding="utf-8", errors="ignore").read()
    last = None
    for attempt in range(3):
        for base in BASES:
            try:
                with urllib.request.urlopen(base + rel + ".arff", timeout=60) as r:
                    txt = r.read().decode("utf-8", errors="ignore")
                if "@" in txt and len(txt) > 100:
                    open(local, "w", encoding="utf-8").write(txt)
                    return txt
            except Exception as e:
                last = e
        time.sleep(2 + 3 * attempt)
    raise RuntimeError(f"Download failed for {rel}: {last}")

def parse_arff(text, label_name="class", drop=()):
    attrs, rows, in_data = [], [], False
    for line in text.splitlines():
        s = line.strip()
        if not s or s.startswith("%"):
            continue
        low = s.lower()
        if not in_data:
            if low.startswith("@attribute"):
                rest = s[len("@attribute"):].strip()
                if rest[0] in "'\"":
                    q = rest[0]; e = rest.index(q, 1); name = rest[1:e]; typ = rest[e + 1:].strip()
                else:
                    parts = rest.split(None, 1); name = parts[0]; typ = parts[1] if len(parts) > 1 else ""
                attrs.append((name.strip(), typ.strip()))
            elif low.startswith("@data"):
                in_data = True
            continue
        row = next(csv.reader([s], skipinitialspace=True, quotechar="'"))
        if len(row) < len(attrs):
            row = s.replace(",", " ").split()
        if len(row) != len(attrs):
            continue
        rows.append([c.strip() for c in row])
    names = [a[0].lower() for a in attrs]
    li = names.index(label_name) if label_name in names else len(names) - 1
    y_raw = np.array([r[li] for r in rows])
    dropl = [d.lower() for d in drop]
    feats = [i for i in range(len(attrs)) if i != li and attrs[i][0].lower() not in dropl]
    X = np.full((len(rows), len(feats)), np.nan)
    for j, fi in enumerate(feats):
        for i, r in enumerate(rows):
            try:
                X[i, j] = float(r[fi])
            except ValueError:
                pass
    X = X[:, ~np.all(np.isnan(X), axis=0)]
    if np.isnan(X).any():                                   # median imputation of missing values
        med = np.nanmedian(X, axis=0); ii = np.where(np.isnan(X)); X[ii] = np.take(med, ii[1])
    X = X[:, X.std(0) > 1e-12]                             # remove constant attributes
    _, y = np.unique(y_raw, return_inverse=True)
    return X, y


def load_benchmark(cache=None):
    global CACHE
    if cache: CACHE = os.path.abspath(cache)
    os.makedirs(CACHE, exist_ok=True)
    DATA, META = {}, []
    for name, rel, group, drop in REGISTRY:
        X, y = parse_arff(fetch_text(rel), "class", drop)
        DATA[name] = (StandardScaler().fit_transform(X).astype(np.float64), y, group)
    Xd, yd = load_digits(return_X_y=True)
    Xd = Xd[:, Xd.std(0) > 1e-12]
    DATA["Digits"] = (StandardScaler().fit_transform(Xd), yd, "Real")
    for name, (X, y, g) in DATA.items():
        cnt = np.bincount(y)
        META.append(dict(Dataset=name, Group=g, n=X.shape[0], d=X.shape[1], k=len(cnt),
                         MinClass=int(cnt.min()), MaxClass=int(cnt.max()), Imbalance=round(cnt.max() / cnt.min(), 2)))
    return DATA, pd.DataFrame(META)
