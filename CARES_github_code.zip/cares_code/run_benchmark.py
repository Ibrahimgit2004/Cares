"""
run_benchmark.py -- full-data protocol (30 seeds for the stochastic initialisers, one run for the deterministic ones)
and 90 % sub-sampling protocol (20 draws, all methods) on the 29 public datasets, 12 initialisers, plus
Friedman / Nemenyi / Wilcoxon-Holm statistics.
Usage:  python run_benchmark.py [out_dir]
"""
import os, sys, time
import numpy as np, pandas as pd
from threadpoolctl import threadpool_limits
from cares_core import *
from benchmark_data import load_benchmark

OUT = sys.argv[1] if len(sys.argv) > 1 else "benchmark_outputs"
os.makedirs(OUT, exist_ok=True)
R_STOCH, R_SUB, SUB_FRAC = 30, 20, 0.90
T0 = time.time()
def log(m): print(f"[{(time.time()-T0)/60:6.1f} min] {m}", flush=True)

DATA, META = load_benchmark(os.path.join(OUT, "data_cache"))
META.to_csv(os.path.join(OUT, "dataset_summary.csv"), index=False)
log(f"loaded {len(DATA)} datasets")

rows = []                                   # ---- Experiment 1: full data protocol
with threadpool_limits(limits=1):
    for dn, (X, y, grp) in DATA.items():
        k = len(np.unique(y)); G = gt_centres_of(X, y) if grp == "Synthetic" else None
        for mth, (f, stoch) in METHODS.items():
            for r in (range(R_STOCH) if stoch else [0]):
                rec = evaluate_once(X, y, k, mth, seed=r, gt_centres=G)
                rec.update(dataset=dn, group=grp, method=mth, run=r); rows.append(rec)
        log(f"Exp-1 done: {dn}")
E1 = pd.DataFrame(rows)
best = E1.groupby("dataset")["final_sse"].min()
E1["sse_gap_pct"] = 100.0 * (E1["final_sse"] - E1["dataset"].map(best)) / E1["dataset"].map(best)
E1.to_csv(os.path.join(OUT, "exp1_full_runs.csv"), index=False)

rows = []                                   # ---- Experiment 2: 90 % sub-sampling protocol
with threadpool_limits(limits=1):
    for dn, (X, y, grp) in DATA.items():
        k = len(np.unique(y))
        for r in range(R_SUB):
            sub = np.random.default_rng(10_000 + r).choice(len(X), int(SUB_FRAC * len(X)), replace=False)
            Xs, ys = X[sub], y[sub]; G = gt_centres_of(Xs, ys) if grp == "Synthetic" else None
            for mth in METHOD_NAMES:
                rec = evaluate_once(Xs, ys, k, mth, seed=r, gt_centres=G)
                rec.update(dataset=dn, group=grp, method=mth, rep=r); rows.append(rec)
        log(f"Exp-2 done: {dn}")
E2 = pd.DataFrame(rows)
b2 = E2.groupby(["dataset", "rep"])["final_sse"].transform("min")
E2["sse_gap_pct"] = 100.0 * (E2["final_sse"] - b2) / b2
E2.to_csv(os.path.join(OUT, "exp2_subsampling_runs.csv"), index=False)

def mean_table(E):
    g = E.groupby(["dataset", "method"])[["ari", "nmi", "sse_gap_pct", "iters"]].mean()
    return g.groupby("method").mean().loc[METHOD_NAMES]
T1, T2 = mean_table(E1), mean_table(E2)
T1.to_csv(os.path.join(OUT, "table_mean_full.csv")); T2.to_csv(os.path.join(OUT, "table_mean_subsampling.csv"))
R1, F1, W1 = stat_block(E1, "Full-data", list(DATA)); R2, F2, W2 = stat_block(E2, "90%-subsampling", list(DATA))
pd.concat([R1, R2]).to_csv(os.path.join(OUT, "average_ranks.csv"), index=False)
pd.concat([F1, F2]).to_csv(os.path.join(OUT, "friedman_nemenyi.csv"), index=False)
pd.concat([W1, W2]).to_csv(os.path.join(OUT, "wilcoxon_holm.csv"), index=False)
log("FULL-DATA MEANS\n" + T1.round(4).to_string()); log("SUBSAMPLING MEANS\n" + T2.round(4).to_string()); log("done")
