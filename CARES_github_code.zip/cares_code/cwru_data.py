"""
cwru_data.py -- vibration-signal clustering datasets for the condition-monitoring application of CARES.

Source: Case Western Reserve University Bearing Data Center, 12 kHz drive-end fault data and normal baseline
(https://engineering.case.edu/bearingdatacenter).  The .mat files are fetched from a public GitHub mirror
(https://github.com/s-whynot/CWRU-dataset) that keeps the original file names (e.g. 105_0.mat = inner race
0.007 in, motor load 0 hp).

One *scenario* is one clustering dataset built from an accelerometer channel (drive end DE or fan end FE), a
motor load (0-3 hp, or all four pooled) and a diagnostic task:
    T10 : 10 classes = Normal + {inner race, ball, outer race @6 o'clock} x {0.007, 0.014, 0.021 in}
    T4  : 4 classes  = Normal, inner race, ball, outer race (the three fault diameters merged)
Samples are non-overlapping windows of 2048 points (0.17 s at 12 kHz), with the same number of windows per file.
Each window is described by 10 time-domain, 3 spectral-shape and 8 band-energy-ratio features
(see feature_names).  Preprocessing as in the benchmark study: constant features dropped, z-score
standardisation, k = number of classes.
"""
import os, glob, subprocess
import numpy as np
import scipy.io as sio
from scipy.stats import kurtosis, skew
from sklearn.preprocessing import StandardScaler

MIRROR = "https://github.com/s-whynot/CWRU-dataset"
FS, WIN = 12000, 2048
SIZES = ["007", "014", "021"]
LOADS = [0, 1, 2, 3]
CHANNELS = ["DE", "FE"]

def ensure_data(root="CWRU-dataset"):
    if not os.path.isdir(os.path.join(root, "12k_Drive_End_Bearing_Fault_Data")):
        subprocess.run(["git", "clone", "--depth", "1", MIRROR, root], check=True)
    return os.path.abspath(root)

def _file_for(root, cls, size, load):
    base = os.path.join(root, "12k_Drive_End_Bearing_Fault_Data")
    if cls == "Normal":
        hits = sorted(glob.glob(os.path.join(root, f"Normal/*_Normal_{load}.mat")))
    elif cls == "OR":
        hits = sorted(glob.glob(os.path.join(base, f"OR/{size}/*@6_{load}.mat")) +
                      glob.glob(os.path.join(base, f"OR/{size}/@6/*_{load}.mat")))
    else:
        hits = sorted(glob.glob(os.path.join(base, f"{cls}/{size}/*_{load}.mat")))
    if len(hits) != 1:
        raise FileNotFoundError((cls, size, load, hits))
    return hits[0]

def _signal(path, channel):
    m = sio.loadmat(path)
    key = [k for k in m if k.endswith(f"_{channel}_time")]
    if not key:
        raise KeyError((path, channel))
    return m[key[0]].ravel().astype(float)

feature_names = (["rms", "peak", "peak_to_peak", "crest_factor", "kurtosis", "skewness", "shape_factor",
                  "impulse_factor", "clearance_factor", "zero_cross_rate",
                  "spec_centroid", "spec_spread", "spec_kurtosis"] + [f"band{i+1}_ratio" for i in range(8)])

def window_features(w):
    w = w - w.mean()
    rms = np.sqrt(np.mean(w ** 2)); ab = np.abs(w); peak = ab.max(); p2p = w.max() - w.min()
    mean_ab = ab.mean(); sra = np.mean(np.sqrt(ab)) ** 2
    f = [rms, peak, p2p, peak / rms, kurtosis(w), skew(w), rms / mean_ab, peak / mean_ab, peak / sra,
         np.mean(np.abs(np.diff(np.sign(w))) > 0)]
    sp = np.abs(np.fft.rfft(w * np.hanning(len(w)))) ** 2; fr = np.fft.rfftfreq(len(w), 1.0 / FS)
    tot = sp.sum() + 1e-30; cen = (fr * sp).sum() / tot
    spr = np.sqrt(((fr - cen) ** 2 * sp).sum() / tot)
    skt = (((fr - cen) ** 4) * sp).sum() / tot / (spr ** 4 + 1e-30)
    edges = np.linspace(0, FS / 2, 9)
    band = [sp[(fr >= edges[i]) & (fr < edges[i + 1] + (1e-9 if i == 7 else 0))].sum() / tot for i in range(8)]
    return np.array(f + [cen, spr, skt] + band)

CLASSES = [("Normal", None)] + [(c, s) for c in ("IR", "B", "OR") for s in SIZES]

def raw_windows(root, load, channel):
    """Raw feature matrix (windows x features) and 10-class labels for one load/channel."""
    sigs = [_signal(_file_for(root, cls, size, load), channel) for cls, size in CLASSES]
    nw = min(len(s) // WIN for s in sigs)                       # equal number of windows per class
    X, y = [], []
    for ci, sig in enumerate(sigs):
        for t in range(nw):
            X.append(window_features(sig[t * WIN:(t + 1) * WIN])); y.append(ci)
    return np.array(X), np.array(y)

TYPE_OF = [0, 1, 1, 1, 2, 2, 2, 3, 3, 3]                       # Normal / IR / B / OR for the 10 classes

def _finish(X, y, task):
    if task == "T4":
        y = np.array([TYPE_OF[c] for c in y])
    X = X[:, X.std(0) > 1e-12]
    return StandardScaler().fit_transform(X), y

def all_scenarios(root):
    """20 scenarios: {DE, FE} x {load 0,1,2,3 and pooled} x {T10, T4}."""
    out = {}
    for ch in CHANNELS:
        raw = {ld: raw_windows(root, ld, ch) for ld in LOADS}
        raw["pooled"] = (np.vstack([raw[l][0] for l in LOADS]), np.concatenate([raw[l][1] for l in LOADS]))
        for ld in LOADS + ["pooled"]:
            for task in ("T10", "T4"):
                name = f"{ch}-{'all-loads' if ld == 'pooled' else f'{ld}hp'}-{task}"
                X, y = _finish(*raw[ld], task)
                out[name] = (X, y)
    return out
