"""
cares_core.py -- core code of the CARES study.

CARES: Crowding Aware Renyi Entropy Seeding, a deterministic seeding method for k-means.
This module holds the proposed method, the eleven baseline initialisers and the evaluation utilities
(Lloyd run, SSE, centroid index, metrics, statistics).  Every experiment imports from here so that each
method is implemented exactly once.

CKmeans and FCKmeans follow the MATLAB code published by their author
(https://github.com/Layebuniv/fckmeans, files ckmeans.m and fckmeansBest.m).
"""
import os, time, warnings
warnings.filterwarnings("ignore")
os.environ.setdefault("OMP_NUM_THREADS", "1")
import numpy as np
import pandas as pd
from scipy import stats
from scipy.spatial.distance import cdist
from sklearn.cluster import KMeans, kmeans_plusplus
from sklearn.neighbors import NearestNeighbors, LocalOutlierFactor
from sklearn.metrics import (adjusted_rand_score, normalized_mutual_info_score, fowlkes_mallows_score,
                             silhouette_score, davies_bouldin_score, calinski_harabasz_score)

MAX_ITER, TOL = 300, 1e-4     # Lloyd settings used for every initialiser (one initialisation per run)

def init_forgy(X, k, rng):
    """Forgy (1965): k distinct data points chosen uniformly at random."""
    return X[rng.choice(len(X), k, replace=False)].copy()

def init_random_partition(X, k, rng):
    """Random Partition: random label assignment, centres = partition means."""
    lab = rng.integers(0, k, len(X)); lab[rng.choice(len(X), k, replace=False)] = np.arange(k)
    return np.vstack([X[lab == j].mean(0) for j in range(k)])

def init_kmeanspp(X, k, rng):
    """Greedy k-means++ (Arthur & Vassilvitskii, 2007) as implemented in scikit-learn (2+ln k local trials)."""
    C, _ = kmeans_plusplus(X, k, random_state=int(rng.integers(0, 2**31 - 1)))
    return C

def _farthest_first(X, k, first):
    idx = [first]; D = ((X - X[first]) ** 2).sum(1)
    for _ in range(1, k):
        i = int(np.argmax(D)); idx.append(i); D = np.minimum(D, ((X - X[i]) ** 2).sum(1))
    return X[idx].copy()

def init_maximin(X, k, rng):
    """Maximin / farthest-first traversal (Gonzalez, 1985) with a random first centre."""
    return _farthest_first(X, k, int(rng.integers(len(X))))

def init_kkz(X, k, rng=None):
    """KKZ (Katsavounidis et al., 1994): first centre = largest-norm point, then farthest-first."""
    return _farthest_first(X, k, int(np.argmax((X ** 2).sum(1))))

def _hierarchical_split(X, k, use_pca):
    groups = [np.arange(len(X))]
    while len(groups) < k:
        sse = [((X[g] - X[g].mean(0)) ** 2).sum() if len(g) > 1 else -1.0 for g in groups]
        g = groups.pop(int(np.argmax(sse))); Z = X[g]; mu = Z.mean(0)
        if use_pca:
            _, _, vt = np.linalg.svd(Z - mu, full_matrices=False); proj = (Z - mu) @ vt[0]
        else:
            j = int(np.argmax(Z.var(0))); proj = Z[:, j] - mu[j]
        left = proj <= 0
        if left.all() or (~left).all():
            o = np.argsort(proj, kind="mergesort"); left = np.zeros(len(g), bool); left[o[: len(g) // 2]] = True
        groups += [g[left], g[~left]]
    return np.vstack([X[g].mean(0) for g in groups])

def init_varpart(X, k, rng=None):
    """Var-Part (Su & Dy, 2007): split largest-SSE cell along max-variance axis at its mean."""
    return _hierarchical_split(X, k, False)

def init_pcapart(X, k, rng=None):
    """PCA-Part (Su & Dy, 2007): split largest-SSE cell along its principal axis through the mean."""
    return _hierarchical_split(X, k, True)

def init_robin(X, k, rng=None, min_pts=10, eps=0.05):
    """ROBIN (Al Hasan et al., 2009): LOF-filtered farthest-first seeding; deterministic origin reference."""
    lof = -LocalOutlierFactor(n_neighbors=min(min_pts, len(X) - 1)).fit(X).negative_outlier_factor_
    ok = np.abs(lof - 1.0) <= eps
    if ok.sum() < k:
        ok = np.zeros(len(X), bool); ok[np.argsort(np.abs(lof - 1.0))[: max(5 * k, int(0.2 * len(X)))]] = True
    D = (X ** 2).sum(1); idx = []
    for _ in range(k):
        cand = np.where(ok)[0]; i = int(cand[np.argmax(D[cand])]); idx.append(i); ok[i] = False
        di = ((X - X[i]) ** 2).sum(1); D = di if len(idx) == 1 else np.minimum(D, di)
    return X[idx].copy()

def init_dpc(X, k, rng=None, pct=2.0):
    """Density-peak seeding (Rodriguez & Laio, 2014): top-k of gamma = rho * delta."""
    n = len(X); nn_k = min(n - 1, max(2, int(round(pct / 100 * n))))
    dist, _ = NearestNeighbors(n_neighbors=nn_k + 1).fit(X).kneighbors(X)
    dc = np.median(dist[:, -1]) + 1e-12
    rho = np.exp(-(dist[:, 1:] / dc) ** 2).sum(1) + 1e-9 * np.arange(n) / n
    order = np.argsort(-rho, kind="mergesort"); rank = np.empty(n, int); rank[order] = np.arange(n)
    sq = (X ** 2).sum(1); delta = np.zeros(n)
    for s in range(0, n, 1024):
        rows = order[s:s + 1024]
        D2 = sq[rows, None] + sq[None, :] - 2.0 * (X[rows] @ X.T)
        D2[rank[None, :] >= rank[rows][:, None]] = np.inf
        delta[rows] = np.sqrt(np.maximum(D2.min(1), 0))
    delta[order[0]] = delta[np.isfinite(delta)].max() if n > 1 else 1.0
    gamma = (rho / rho.max()) * (delta / delta.max())
    return X[np.argsort(-gamma, kind="mergesort")[:k]].copy()


def _rank01(v):
    """Rank-normalise a vector to [0, 1] (scale-free, robust to heavy tails)."""
    r = np.empty(len(v)); r[np.argsort(v, kind="mergesort")] = np.arange(len(v))
    return r / max(len(v) - 1, 1)

def cares_init(X, k, rng=None, m=None, beta=1.0, use_feature_entropy=True, cd_mode="hybrid",
               use_local_adaptive=True, use_entropy=True, greedy=True, refine=True, return_info=False):
    """
    Crowding Aware Renyi Entropy Seeding (CARES) for k-means.
      Stage 1  Entropy-adaptive feature weights  w_j = 0.5 + 0.5 * (1-E_j)/mean(1-E)
      Stage 2  Hybrid crowding distance = alpha*axis-wise (NSGA-II) CD + (1-alpha)*kNN CD,
               alpha = 1/(1+d) adapts to dimensionality
      Stage 3  Locally adaptive relative crowding  (mean neighbour CD / own CD)
      Stage 4  Local quadratic Renyi entropy (Parzen information potential), bandwidth = median m-NN distance
      Stage 5  Seed potential P = rank(relative density * information potential)
      Stage 6  Deterministic greedy selection: L = 2 + ln k candidates by D(x)*P(x)^beta,
               the one giving the lowest seeding potential (SSE) is accepted
      Stage 7  Local mode refinement: potential-weighted mean of the seed's m-neighbourhood
    Fully deterministic (no random numbers are used; `rng` is accepted only for a common interface).
    """
    n, d = X.shape
    # ---- Stage 1: entropy-adaptive feature weights
    if use_feature_entropy:
        B = int(np.ceil(np.log2(n)) + 1); E = np.ones(d)
        for j in range(d):
            lo, hi = np.percentile(X[:, j], [1, 99])
            if hi - lo > 1e-12:
                h, _ = np.histogram(np.clip(X[:, j], lo, hi), bins=B, range=(lo, hi))
                p = h[h > 0] / n; E[j] = -(p * np.log(p)).sum() / np.log(B)
        dv = 1.0 - E
        w = 0.5 + 0.5 * dv / dv.mean() if dv.mean() > 1e-12 else np.ones(d)
    else:
        E = np.ones(d); w = np.ones(d)
    Xw = X * np.sqrt(w)
    # ---- Stage 2: hybrid crowding distance
    if m is None:
        m = int(np.clip(np.round(np.sqrt(n) / 2), 5, 30))
    m = int(min(m, n - 1))
    dist, ind = NearestNeighbors(n_neighbors=m + 1).fit(Xw).kneighbors(Xw)
    dist, ind = dist[:, 1:], ind[:, 1:]
    cd_knn = dist.mean(1)
    cd_axis = np.zeros(n)
    for j in range(d):
        o = np.argsort(Xw[:, j], kind="mergesort"); v = Xw[o, j]; span = v[-1] - v[0]
        if span < 1e-12 or n < 3:
            continue
        g = np.empty(n); g[1:-1] = (v[2:] - v[:-2]) / span; g[0] = g[-1] = g[1:-1].max()
        cd_axis[o] += w[j] * g
    cd_axis /= w.sum()
    alpha = 1.0 / (1.0 + d)
    if cd_mode == "hybrid":
        cd = alpha * _rank01(cd_axis) + (1.0 - alpha) * _rank01(cd_knn)
    elif cd_mode == "axis":
        cd = _rank01(cd_axis)
    else:
        cd = _rank01(cd_knn)
    # ---- Stage 3: locally adaptive relative crowding (>1 at local modes, <1 at borders/outliers)
    if use_local_adaptive:
        cdr = cd + 1e-3
        rho = _rank01(cdr[ind].mean(1) / cdr)
    else:
        rho = 1.0 - cd
    # ---- Stage 4: local quadratic Renyi entropy via Parzen information potential
    if use_entropy:
        sigma = np.median(dist[:, -1]) + 1e-12
        ip = np.exp(-(dist / sigma) ** 2 / 4.0).mean(1)      # H2 = -log(ip): high ip <=> low entropy
        ent = _rank01(ip)
        P = _rank01(rho * ent)
    else:
        P = _rank01(rho)
    P = 0.05 + 0.95 * P
    # ---- Stage 6: deterministic greedy density-separation selection
    L = int(2 + np.log(k))
    idx = [int(np.argmax(P))]
    D = ((Xw - Xw[idx[0]]) ** 2).sum(1)
    for t in range(1, k):
        score = (D / (D.max() + 1e-300)) * P ** beta
        score[idx] = -np.inf
        if greedy:
            Lt = int(min(L, n - len(idx)))
            cand = np.argpartition(-score, Lt - 1)[:Lt]
            cand = cand[np.isfinite(score[cand])]
            pots = [np.minimum(D, ((Xw - Xw[c]) ** 2).sum(1)).sum() for c in cand]
            i = int(cand[int(np.argmin(pots))])
        else:
            i = int(np.argmax(score))
        idx.append(i)
        D = np.minimum(D, ((Xw - Xw[i]) ** 2).sum(1))
    C = X[idx].copy()
    # ---- Stage 7: local mode refinement
    if refine:
        for c, i in enumerate(idx):
            nb = np.r_[i, ind[i]]; ww = P[nb]
            C[c] = (X[nb] * ww[:, None]).sum(0) / ww.sum()
    if return_info:
        return C, dict(P=P, idx=idx, w=w, E=E, m=m, alpha=alpha, cd_axis=cd_axis, cd_knn=cd_knn, rho=rho)
    return C


# ---------------------------------------------------------------------------------------------
# CKmeans / FCKmeans (Layeb, 2023): port of ckmeans.m / fckmeansBest.m (MATLAB)
# ---------------------------------------------------------------------------------------------
def _layeb_crowding(X):
    """Mcrowding_distance of Layeb's code: two artificial points (min-10, max+10) are appended, the two
    extreme points of every feature receive m*max(all values), interior points accumulate the gap between
    their sorted neighbours; the artificial points are removed at the end."""
    n0, m = X.shape
    O = np.vstack([X, X.min(0) - 10.0, X.max(0) + 10.0])
    n = n0 + 2
    big = m * O.max()                       # mx = m*max(objectives,[],"all")
    d = np.zeros(n)
    for i in range(m):
        order = np.argsort(O[:, i], kind="stable")      # MATLAB sort is stable
        d[order[0]] = big                               # assignment (not accumulation), as in the MATLAB code
        d[order[-1]] = big
        d[order[1:-1]] += O[order[2:], i] - O[order[:-2], i]
    return d[:-2]

def init_ckmeans(X, k, rng=None):
    """CKmeans: the k most crowded points (smallest modified crowding distance) become the centroids."""
    cd = _layeb_crowding(X)
    return X[np.argsort(cd, kind="stable")[:k]].copy()

def init_fckmeans(X, k, rng=None):
    """FCKmeans (fckmeansBest.m): first the most crowded point, then repeatedly the point that maximises
    (distance to the nearest chosen centroid) / (crowding distance)."""
    cd = _layeb_crowding(X)
    C = np.zeros((k, X.shape[1])); C[0] = X[np.argsort(cd, kind="stable")[0]]
    for i in range(1, k):
        md = cdist(X, C[:i]).min(1)
        with np.errstate(all="ignore"):
            ratio = md / cd
        j = 0 if np.all(np.isnan(ratio)) else int(np.nanargmax(ratio))   # MATLAB max ignores NaN, first maximum
        C[i] = X[j]
    return C

# registry: name -> (function, stochastic?)
METHODS = {
    "Forgy":     (init_forgy, True),
    "RandPart":  (init_random_partition, True),
    "KMeans++":  (init_kmeanspp, True),
    "Maximin":   (init_maximin, True),
    "KKZ":       (init_kkz, False),
    "Var-Part":  (init_varpart, False),
    "PCA-Part":  (init_pcapart, False),
    "ROBIN":     (init_robin, False),
    "DPC-Seed":  (init_dpc, False),
    "CKmeans":   (init_ckmeans, False),
    "FCKmeans":  (init_fckmeans, False),
    "CARES":     (cares_init, False),
}
METHOD_NAMES = list(METHODS)
PROPOSED = "CARES"

def sse_of(X, C, chunk=4096):
    tot = 0.0; cn = (C ** 2).sum(1)
    for s in range(0, len(X), chunk):
        Z = X[s:s + chunk]; D2 = (Z ** 2).sum(1)[:, None] + cn[None, :] - 2.0 * Z @ C.T
        tot += np.maximum(D2.min(1), 0).sum()
    return float(tot)

def centroid_index(A, B):
    """Centroid Index (Franti et al., 2014): number of mis-located cluster prototypes (0 = correct structure)."""
    def orphans(P, Q):
        return len(Q) - len(np.unique(cdist(P, Q).argmin(1)))
    return int(max(orphans(A, B), orphans(B, A)))

def run_lloyd(X, C):
    km = KMeans(n_clusters=len(C), init=C, n_init=1, max_iter=MAX_ITER, tol=TOL, algorithm="lloyd").fit(X)
    return km

def evaluate_once(X, y, k, method, seed, gt_centres=None, internal=False):
    f, _ = METHODS[method] if isinstance(method, str) else (method, None)
    t0 = time.perf_counter(); C0 = f(X, k, np.random.default_rng(seed)); t_init = time.perf_counter() - t0
    sse0 = sse_of(X, C0)
    t1 = time.perf_counter(); km = run_lloyd(X, C0); t_km = time.perf_counter() - t1
    lab = km.labels_
    rec = dict(init_sse=sse0, final_sse=float(km.inertia_), iters=int(km.n_iter_),
               ari=adjusted_rand_score(y, lab), nmi=normalized_mutual_info_score(y, lab),
               fmi=fowlkes_mallows_score(y, lab), t_init=t_init, t_total=t_init + t_km)
    if gt_centres is not None:
        rec["ci_init"] = centroid_index(C0, gt_centres); rec["ci"] = centroid_index(km.cluster_centers_, gt_centres)
    if internal:
        nl = len(np.unique(lab))
        if nl > 1:
            ss = min(len(X), 3000)
            rec["silhouette"] = silhouette_score(X, lab, sample_size=ss, random_state=0)
            rec["dbi"] = davies_bouldin_score(X, lab); rec["chi"] = calinski_harabasz_score(X, lab)
        else:
            rec["silhouette"], rec["dbi"], rec["chi"] = np.nan, np.nan, np.nan
    return rec

def gt_centres_of(X, y):
    return np.vstack([X[y == j].mean(0) for j in np.unique(y)])


# ---------------------------------------------------------------------------------------------
# Statistics: Friedman / Iman-Davenport / Nemenyi / Wilcoxon-Holm over a table of per-dataset means
# ---------------------------------------------------------------------------------------------
def avg_ranks(M, lower_better):
    return M.rank(axis=1, ascending=lower_better, method="average").mean(0)

def nemenyi_cd(k, N, alpha=0.05):
    q = stats.studentized_range.ppf(1 - alpha, k, np.inf) / np.sqrt(2)
    return q * np.sqrt(k * (k + 1) / (6.0 * N))

def holm(pvals):
    p = np.asarray(pvals, float); o = np.argsort(p); m = len(p); adj = np.empty(m); run = 0.0
    for i, j in enumerate(o):
        run = max(run, (m - i) * p[j]); adj[j] = min(1.0, run)
    return adj

def stat_block(E, tag, datasets, methods=None, proposed=PROPOSED, metrics=None):
    """E: long dataframe with columns dataset, method and the metric columns.
    Returns (average ranks, Friedman block, Wilcoxon-Holm block)."""
    methods = methods or METHOD_NAMES
    metrics = metrics or {"ari": ("ARI", False), "nmi": ("NMI", False), "fmi": ("FMI", False),
                          "sse_gap_pct": ("SSE gap (%)", True), "iters": ("Iterations", True)}
    out_rank, out_fried, out_wil = [], [], []
    for met, (label, lower) in metrics.items():
        M = E.groupby(["dataset", "method"])[met].mean().unstack("method")[methods].loc[list(datasets)]
        ar = avg_ranks(M, lower)
        chi, pf = stats.friedmanchisquare(*[M[c].values for c in methods])
        N, kk = M.shape; cd = nemenyi_cd(kk, N)
        ff = (N - 1) * chi / (N * (kk - 1) - chi) if N * (kk - 1) - chi > 0 else np.inf
        p_id = 1 - stats.f.cdf(ff, kk - 1, (kk - 1) * (N - 1)) if np.isfinite(ff) else 0.0
        out_fried.append(dict(protocol=tag, metric=label, N_datasets=N, k_methods=kk, friedman_chi2=chi,
                              friedman_p=pf, iman_davenport_F=ff, iman_davenport_p=p_id, nemenyi_CD=cd,
                              best_method=ar.idxmin(), best_avg_rank=ar.min(), proposed_avg_rank=ar[proposed]))
        for mth in methods:
            out_rank.append(dict(protocol=tag, metric=label, method=mth, avg_rank=ar[mth]))
        ps, recs = [], []
        tie_tol = 1e-3 if met != "iters" else 0.05
        for mth in methods:
            if mth == proposed:
                continue
            dlt = M[proposed] - M[mth]
            better = (dlt < -tie_tol) if lower else (dlt > tie_tol)
            worse = (dlt > tie_tol) if lower else (dlt < -tie_tol)
            try:
                p = stats.wilcoxon(M[proposed], M[mth], zero_method="zsplit").pvalue if np.any(np.abs(dlt) > 0) else 1.0
            except ValueError:
                p = 1.0
            ps.append(p)
            recs.append(dict(protocol=tag, metric=label, comparison=f"{proposed} vs {mth}",
                             wins=int(better.sum()), ties=int((~better & ~worse).sum()), losses=int(worse.sum()),
                             mean_diff=float(dlt.mean()), wilcoxon_p=p))
        for rcd, pa in zip(recs, holm(ps)):
            rcd["holm_p"] = pa; rcd["significant_0.05"] = bool(pa < 0.05)
        out_wil += recs
    return pd.DataFrame(out_rank), pd.DataFrame(out_fried), pd.DataFrame(out_wil)
